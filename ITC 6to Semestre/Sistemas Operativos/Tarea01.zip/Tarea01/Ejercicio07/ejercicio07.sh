#!/bin/bash

echo "Estoy en el background! $$"

while true; do 
	echo "hola"
	sleep 2
done
